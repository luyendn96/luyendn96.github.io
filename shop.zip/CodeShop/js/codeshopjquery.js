$(document).ready(function(e) {
	$(".slideshow").cycle(
	{
		next: '.next',
		prev: '.prev'
	}

	);

});
